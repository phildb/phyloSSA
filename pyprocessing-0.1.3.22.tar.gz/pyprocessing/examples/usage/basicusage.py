from pyprocessing import *

smooth()
for i in range(10):
    line(i*5+5,20,i*5+50,80)

run()

from pyprocessing import *

size(200,200)
font = createFont("Times New Roman", 20); 
textFont(font); 
textAlign(CENTER,CENTER)
text("The quick brown\nfox jumps over\nthe lazy dogs", width/2, height/2) 

run()

from pyprocessing import *

background(0);
noStroke();
# Sets the default ambient 
# and directional light
lights();
translate(20, 50, 0);
sphere(30);
translate(60, 0, 0);
sphere(30);

run()

from pyprocessing import *

font = createFont("times", 12); 
textFont(font); 
s = "The quick brown fox jumped over the lazy dog."
text(s, 15, 20, 70, 70)

run()

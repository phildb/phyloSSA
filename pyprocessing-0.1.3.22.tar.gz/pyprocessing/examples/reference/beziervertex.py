from pyprocessing import *

beginShape()
vertex(30, 20)
bezierVertex(80, 0, 80, 75, 30, 75)
bezierVertex(50, 75, 60, 25, 30, 20)
endShape()

run()

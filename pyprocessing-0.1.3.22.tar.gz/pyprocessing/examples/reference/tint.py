from pyprocessing import *

b = loadImage("images/arch.jpg");
image(b, 0, 0); 
# Tint blue
tint(0, 153, 204, 126); 
image(b, 50, 0);

run()


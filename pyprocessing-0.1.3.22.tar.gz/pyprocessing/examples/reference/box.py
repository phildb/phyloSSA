from pyprocessing import *

translate(58, 48, 0); 
rotateY(0.5);
box(40);

run()

from pyprocessing import *

font = createFont("Times",32); 
textFont(font); 
text("word", 15, 60, -30); 
fill(0, 102, 153);
text("word", 15, 60);

run()

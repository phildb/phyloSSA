from pyprocessing import *


size(100, 100);
background(0);
noStroke();
spotLight(51, 102, 126, 80, 20, 40, -1, 0, 0, PI/2, 2);
translate(20, 50, 0);
sphere(30);

run()

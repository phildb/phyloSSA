from pyprocessing import *


size(100, 100)
translate(width/4, height/4)
shearY(PI/4.0)
rect(0, 0, 30, 30)


run()

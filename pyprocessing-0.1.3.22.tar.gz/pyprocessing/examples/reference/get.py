from pyprocessing import *

myImage = loadImage("images/arch.jpg");
image(myImage, 0, 0);
cp = get();
image(cp, 50, 0);

run()

from pyprocessing import *

def setup():
  size(screen.width, screen.height)
  
def draw():
  line(0, 0, screen.width, screen.height)

run()

from pyprocessing import *

b = loadImage("images/arch.jpg")
image (b,0,0)

run()


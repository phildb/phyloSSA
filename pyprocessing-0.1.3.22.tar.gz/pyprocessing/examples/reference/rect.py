from pyprocessing import *

rect (10,10,80,80)

run()

from pyprocessing import *

size(100, 100);
background(0);
noStroke();
background(0);
directionalLight(204, 204, 204, .5, 0, -1);
emissive(0, 26, 51);
translate(70, 50, 0);
sphere(30);

run()

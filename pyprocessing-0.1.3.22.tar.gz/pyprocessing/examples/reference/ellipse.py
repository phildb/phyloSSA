from pyprocessing import *

size(200,200,resizable=True)
def draw():
    background(200)
    ellipse(width/2,height/2,width-40,height-40)

run()

from pyprocessing import *

font = createFont("Times New Roman", 24); 
textFont(font); 
text("word", 15, 30); 
fill(0, 102, 153);
text("word", 15, 60);
fill(0, 102, 153, 51);
text("word", 15, 90);

run()

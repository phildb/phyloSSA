from pyprocessing import *

noStroke();
lights();
translate(58, 48, 0);
sphere(28);

run()

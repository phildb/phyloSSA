from pyprocessing import *

#TexturedCube
#by Dave Bollinger.
#Drag mouse to rotate cube. Demonstrates use of u/v coords in 
#vertex() and effect on texture(). 

rotx = PI/4;
roty = PI/4;

def setup():
  global tex
  size(640, 360);
  tex = loadImage("images/tex.jpg");
  textureMode(NORMALIZED);
  fill(255);
  stroke(color(44,48,32));

def draw():
  background(0);
  noStroke();
  translate(width/2.0, height/2.0, -100);
  rotateX(rotx);
  rotateY(roty);
  scale(90);
  TexturedCube(tex);

def TexturedCube(tex):
  beginShape(QUADS);
  texture(tex);
  vertex(-1, -1,  1, 0, 0);
  vertex( 1, -1,  1, 1, 0);
  vertex( 1,  1,  1, 1, 1);
  vertex(-1,  1,  1, 0, 1);
  vertex( 1, -1, -1, 0, 0);
  vertex(-1, -1, -1, 1, 0);
  vertex(-1,  1, -1, 1, 1);
  vertex( 1,  1, -1, 0, 1);
  vertex(-1,  1,  1, 0, 0);
  vertex( 1,  1,  1, 1, 0);
  vertex( 1,  1, -1, 1, 1);
  vertex(-1,  1, -1, 0, 1);
  vertex(-1, -1, -1, 0, 0);
  vertex( 1, -1, -1, 1, 0);
  vertex( 1, -1,  1, 1, 1);
  vertex(-1, -1,  1, 0, 1);
  vertex( 1, -1,  1, 0, 0);
  vertex( 1, -1, -1, 1, 0);
  vertex( 1,  1, -1, 1, 1);
  vertex( 1,  1,  1, 0, 1);
  vertex(-1, -1, -1, 0, 0);
  vertex(-1, -1,  1, 1, 0);
  vertex(-1,  1,  1, 1, 1);
  vertex(-1,  1, -1, 0, 1);
  endShape();

def mouseDragged():
  global rotx,roty
  rate = 0.01;
  rotx += (pmouse.y-mouse.y) * rate;
  roty += (mouse.x-pmouse.x) * rate;
  
run()

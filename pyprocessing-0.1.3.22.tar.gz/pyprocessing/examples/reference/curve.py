from pyprocessing import *

noFill();
stroke(255, 102, 0);
curve(5, 26, 5, 26, 73, 24, 73, 61);
stroke(0); 
curve(5, 26, 73, 24, 73, 61, 15, 65); 
stroke(255, 102, 0);
curve(73, 24, 73, 61, 15, 65, 15, 65);

run()

from pyprocessing import *

background(0);
noStroke();
smooth();
fill(242, 204, 47, 160);
ellipse(47, 36, 64, 64);
fill(174, 221, 60, 160);
ellipse(90, 47, 64, 64);
fill(116, 193, 206, 160);
ellipse(57, 79, 64, 64);

run()
